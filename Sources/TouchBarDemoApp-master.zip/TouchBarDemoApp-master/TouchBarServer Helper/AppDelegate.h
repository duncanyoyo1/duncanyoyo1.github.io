//
//  AppDelegate.h
//  TouchBarServer Helper
//
//  Created by Robbert Klarenbeek on 03/11/2016.
//  Copyright © 2016 Bikkelbroeders. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

