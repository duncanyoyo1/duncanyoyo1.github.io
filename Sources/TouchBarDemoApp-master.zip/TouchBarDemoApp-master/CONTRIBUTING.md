### Please avoid duplicate issues

Before submitting a new issue, please search previous issues first. You can do this on the [issues page](https://github.com/bikkelbroeders/TouchBarDemoApp/issues?q=is%3Aissue).
