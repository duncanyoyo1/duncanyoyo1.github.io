//
//  TouchBarView.h
//  TouchBar
//
//  Created by Robbert Klarenbeek on 12/11/2016.
//  Copyright © 2016 Bikkelbroeders. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TouchBarView : NSView

@end
