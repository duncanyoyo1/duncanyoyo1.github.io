//
//  XirvikSeedbox.h
//  BarMagnet
//
//  Created by Charlotte Tortorella on 26/09/2015.
//  Copyright © 2015 Charlotte Tortorella. All rights reserved.
//

#import "ruTorrentHTTPRPC.h"

@interface XirvikSeedbox : ruTorrentHTTPRPC

@end
