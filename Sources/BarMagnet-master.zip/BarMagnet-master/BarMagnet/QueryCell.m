//
//  QueryCell.m
//  BarMagnet
//
//  Created by Charlotte Tortorella on 24/01/2014.
//  Copyright (c) 2014 Charlotte Tortorella. All rights reserved.
//

#import "QueryCell.h"

@implementation QueryCell

@end
