//
//  SeedStuffSeedbox.h
//  BarMagnet
//
//  Created by Charlotte Tortorella on 2/03/2014.
//  Copyright (c) 2014 Charlotte Tortorella. All rights reserved.
//

#import "rTorrentXMLRPC.h"

@interface SeedStuffSeedbox : rTorrentXMLRPC

@end
