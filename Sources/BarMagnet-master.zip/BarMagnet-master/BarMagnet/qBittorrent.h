//
//  qBittorrent.h
//  Bar Magnet
//
//  Created by Charlotte Tortorella on 13/06/13.
//  Copyright (c) 2013 Charlotte Tortorella. All rights reserved.
//

#import "TorrentClient.h"

@interface qBittorrent : TorrentClient
@end
