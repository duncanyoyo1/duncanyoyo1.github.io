//
//  UINavigationController+NoAutoRotation.h
//  BarMagnet
//
//  Created by Charlotte Tortorella on 20/11/13.
//  Copyright (c) 2013 Charlotte Tortorella. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationControllerNoAutoRotation : UINavigationController

@end
