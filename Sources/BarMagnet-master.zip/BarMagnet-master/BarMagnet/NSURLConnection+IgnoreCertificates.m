//
//  NSURLConnection+IgnoreCertificates.m
//  BarMagnet
//
//  Created by Charlotte Tortorella on 17/01/2014.
//  Copyright (c) 2014 Charlotte Tortorella. All rights reserved.
//

#import "NSURLConnection+IgnoreCertificates.h"

@implementation NSURLConnection (IgnoreCertificates)

@end
