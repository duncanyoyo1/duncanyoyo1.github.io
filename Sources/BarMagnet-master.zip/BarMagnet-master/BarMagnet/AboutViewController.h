//
//  AboutViewController.h
//  BarMagnet
//
//  Created by Charlotte Tortorella on 31/12/2013.
//  Copyright (c) 2013 Charlotte Tortorella. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UITableViewController

@end
