//
//  MNVMApplication.h
//  Mini vMac
//
//  Created by Jesús A. Álvarez on 14/05/2016.
//  Copyright © 2016 namedfork. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MNVMApplication : UIApplication

@end
