//
//  SettingsViewController.h
//  Mini vMac
//
//  Created by Jesús A. Álvarez on 07/05/2016.
//  Copyright © 2016 namedfork. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UITableViewController

- (IBAction)showInsertDisk:(id)sender;
- (IBAction)dismiss:(id)sender;

@end
